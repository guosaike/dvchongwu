from django.apps import AppConfig


class DvchongwuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dvchongwu'
