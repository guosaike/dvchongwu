<template>
  <div>
    <div class="title">我的订单</div>
    <el-tabs v-model="activeName">
      <el-tab-pane label="全部" name="全部"></el-tab-pane>
      <el-tab-pane label="待付款" name="待付款"></el-tab-pane>
      <el-tab-pane label="已支付" name="已支付"></el-tab-pane>
    </el-tabs>

    <div>
      <div v-for="item in dddata" :key="item.id" style="margin-bottom:20px;border-bottom: 1px dashed #cedce4;padding: 10px 0;">
                  <div style="display: flex;align-items: center;">
                    <el-avatar :size="32" :src="Host+'/upimg/' + item.img_url"
                      style="flex-shrink: 0;margin-right:10px;width: 150px;height: 150px;"  @click=""  />
                    <div style="flex:1;">
                      <div style="font-weight: 600;font-size: 16px;">卖家：{{ item.shui.username }}</div>
                      <div style="font-size: 14px;color: #999;">景区：{{ item.title }}</div>
                      <div style="font-size: 14px;color: #999;">购买时间：{{ item.gmsj }}</div>

                      <br>
                      
                      <div>{{ item.content }}</div>
                    </div>
                    <!-- <div style="flex-shrink: 0;"><el-button link type="primary">推荐</el-button> 1</div> -->
                  </div>
                </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dddata: [],
    }
  },
  created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.token = localStorage.getItem("token");
    this.isAdmin = localStorage.getItem("isAdmin");
    this.mydingdan();
  },

  methods: {
    mydingdan(){
      this.$api.mydingdan(
            {
                pageNum:1,
                pageSize:20,
                userInfoid:this.userInfoid,
            }
        ).then(res=>{
            if (res.data.code === 200){
                this.dddata = res.data.data
            }
        })
    },
  }
}
</script>

<style>
.title {
  color: #152844;
  font-weight: 600;
  font-size: 18px;
  line-height: 24px;
  margin-bottom: 4px;
}

.order-item {
  margin-top: 16px;
  background: #f7f9fb;
  border-radius: 4px;
  padding: 16px;
  box-sizing: border-box;
}
</style>